import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

const UploadPage = () => {
  const [file, setFile] = useState(null);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleUpload = async () => {
    if (!file) {
      alert("Please select a video file first.");
      return;
    }

    const formData = new FormData();
    formData.append("file", file);

    setLoading(true);

    try {
      const res = await fetch("http://127.0.0.1:8000/api/videos/upload", {
        method: "POST",
        body: formData,
      });

      if (!res.ok) throw new Error("Upload failed");

      const data = await res.json();
      console.log("Backend response:", data);

      // BACKEND RETURNS:
      // {
      //   "video_id": "...",
      //   "result": { "summary": "...", "quiz": "...", ... }
      // }

      navigate(`/video/${data.video_id}`, {
      state: {
        summary: data.result.summary,
        transcript: data.result.transcript
      }
    });

    } catch (err) {
      console.error("Upload Error:", err);
      alert("Error uploading video");
    }

    setLoading(false);
  };

  return (
    <div style={{ padding: "40px", color: "#fff" }}>
      <h1>Upload Video</h1>

      <input
        type="file"
        accept="video/*"
        onChange={(e) => setFile(e.target.files[0])}
        style={{ marginTop: "20px" }}
      />

      <button
        onClick={handleUpload}
        disabled={loading}
        style={{
          marginTop: "20px",
          padding: "10px 20px",
          background: "#00D9FF",
          border: "none",
          color: "#000",
          fontWeight: "bold",
          cursor: "pointer",
        }}
      >
        {loading ? "Processing..." : "Upload & Summarize"}
      </button>
    </div>
  );
};

export default UploadPage;
