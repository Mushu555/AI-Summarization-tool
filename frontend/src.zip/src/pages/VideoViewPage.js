import React from "react";
import { useLocation, useParams } from "react-router-dom";
import styles from "../styles/styles";

const VideoViewPage = () => {
  const { state } = useLocation();
  const { video_id } = useParams();

  if (!state) {
    return (
      <div style={{ color: "white", padding: 20 }}>
        <h2>Error</h2>
        <p>No video data received. Please upload a video again.</p>
      </div>
    );
  }

  const { summary, transcript } = state;

  return (
    <div style={styles.viewContainer}>
      <div style={styles.viewContent}>
        <h1 style={styles.viewTitle}>Video Summary</h1>

        <p><strong>Video ID:</strong> {video_id}</p>

        <div style={styles.contentSection}>
          <h2 style={styles.contentTitle}>Summary</h2>
          <p style={styles.summaryText}>{summary}</p>
        </div>

        <div style={styles.contentSection}>
          <h2 style={styles.contentTitle}>Transcript</h2>
          <p style={{ whiteSpace: "pre-wrap", color: "white" }}>
            {transcript}
          </p>
        </div>
      </div>
    </div>
  );
};

export default VideoViewPage;
