import React, { useState } from 'react';
import styles from '../styles/styles';

const Dashboard = ({ currentPage, setCurrentPage }) => {
  const [videos, setVideos] = useState([
    {
      id: 1,
      title: 'AI and Machine Learning Introduction',
      uploadDate: '2025-11-15',
      duration: '10:35',
      status: 'processed'
    }
  ]);
  const [selectedVideo, setSelectedVideo] = useState(null);

  const handleVideoClick = (video) => {
    setSelectedVideo(video);
    setCurrentPage('view');
  };

  if (currentPage === 'upload') {
    return null; // UploadPage will be rendered from MainApp
  }

  if (currentPage === 'view' && selectedVideo) {
    return null; // VideoViewPage will be rendered from MainApp
  }

  return (
    <div style={styles.dashboardContainer}>
      <div style={styles.dashboardHeader}>
        <h2 style={styles.dashboardTitle}>My Videos</h2>
        <button onClick={() => setCurrentPage('upload')} style={styles.uploadBtnHeader}>
          + Upload Video
        </button>
      </div>

      {videos.length === 0 ? (
        <div style={styles.emptyState}>
          <svg width="120" height="120" viewBox="0 0 24 24" fill="none">
            <path d="M8 5v14l11-7z" fill="#334155" />
          </svg>
          <h3 style={styles.emptyTitle}>No videos yet</h3>
          <p style={styles.emptyText}>Upload your first video to get started with AI analysis</p>
          <button onClick={() => setCurrentPage('upload')} style={styles.emptyButton}>
            Upload Video
          </button>
        </div>
      ) : (
        <div style={styles.videosGrid}>
          {videos.map((video) => (
            <div key={video.id} style={styles.videoCard} onClick={() => handleVideoClick(video)}>
              <div style={styles.videoCardThumb}>
                <div style={styles.playOverlay}>
                  <svg width="48" height="48" viewBox="0 0 24 24" fill="none">
                    <circle cx="12" cy="12" r="10" fill="rgba(0, 217, 255, 0.2)" />
                    <path d="M10 8l6 4-6 4V8z" fill="#00D9FF" />
                  </svg>
                </div>
              </div>
              <div style={styles.videoCardContent}>
                <h3 style={styles.videoCardTitle}>{video.title}</h3>
                <div style={styles.videoCardMeta}>
                  <span style={styles.videoCardDuration}>⏱ {video.duration}</span>
                  <span style={styles.videoCardDate}>📅 {video.uploadDate}</span>
                </div>
                <div style={styles.videoCardFooter}>
                  <span style={video.status === 'processed' ? styles.statusSuccess : styles.statusProcessing}>
                    {video.status === 'processed' ? '✓ Processed' : '⟳ Processing'}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Dashboard;
